<h1 align="center">𝐒𝐜𝐫𝐢𝐛𝐛𝐥𝐞𝐫-𝐏𝐫𝐨𝐣𝐞𝐜𝐭</h1>
<p align="center">👨‍🎓🛰️  ᴛʜɪꜱ ᴘʀᴏᴊᴇᴄᴛ ɪꜱ ᴀꜱꜱɪɢɴᴇᴅ ᴛᴏ ᴍᴇ ᴡʜɪʟᴇ ɪ ᴀᴍ ᴀ ᴛʀᴀɪɴᴇᴇ ɪɴ ᴜᴘɢʀᴀᴅ , ɪᴛ ɪꜱ ᴀ ᴛʏᴘᴇ ᴏꜰ ᴀ ʙʟᴏɢɢɪɴɢ ᴡᴇʙꜱɪᴛᴇ. ᴛʜɪꜱ ɪꜱ ᴛʜᴇ ꜰʀᴏɴᴛ ᴇɴᴅ ᴘᴀʀᴛ ᴏꜰ ᴛʜᴇ ᴡᴇʙꜱɪᴛᴇ , ᴛʜᴇ ᴄᴏᴍᴘʟᴇᴛᴇ ᴘʀᴏᴊᴇᴄᴛ ᴡɪʟʟ ʙᴇ ᴜᴘʟᴏᴀᴅᴇᴅ ᴀꜰᴛᴇʀ 🤖🎯 ɪ ꜰɪɴɪꜱʜ ᴍʏ ᴛʀᴀɪɴɪɴɢ. <p><br>
<a href="https://github.com/ashish2030/Scribbler-Project/fork" target="blank">

<p align="center">
  <img src="https://img.shields.io/github/forks/ashish2030/Scribbler-Project?style=flat-square" alt="Scribbler-Project forks"/>
</a>
<a href="https://github.com/ashish2030/Scribbler-Project/stargazers" target="blank">
<img src="https://img.shields.io/github/stars/ashish2030/Scribbler-Project?style=flat-square" alt="Scribbler-Project"/>
</a>
<a href="https://github.com/ashish2030/Scribbler-Project/issues" target="blank">
<img src="https://img.shields.io/github/issues/ashish2030/Scribbler-Project?style=flat-square" alt="Scribbler-Project"/>
</a>
<a href="https://github.com/ashish2030/Scribbler-Project/pulls" target="blank">
<img src="https://img.shields.io/github/issues-pr/ashish2030/Scribbler-Project?style=flat-square" alt="Scribbler-Project"/>
</a>
  </p>
  
 [![GitHub last commit](https://img.shields.io/github/last-commit/ashish2030/Scribbler-Project)](https://github.com/ashish2030/Scribbler-Project/commits/master)
[![GitHub repo size](https://img.shields.io/github/repo-size/ashish2030/Scribbler-Project)](https://github.com/ashish2030/Scribbler-Project/archive/master.zip)
 
https://user-images.githubusercontent.com/61516051/117543060-d994d900-b038-11eb-8e3c-cdcef2cce735.mp4

<p align="center">
    <a href="https://github.com/Ashish2030/Scribbler-Project" target="blank">View Demo</a>
    ·
    <a href="https://github.com/ashish2030/Scribbler-Project/issues/new/choose">Report Bug</a>
    ·
    <a href="https://github.com/ashish2030/Scribbler-Project/issues/new/choose">Request Feature</a>
</p>
